import React from "react";

function Aside() {
  return <div>Aside</div>;
}

export default Aside;
