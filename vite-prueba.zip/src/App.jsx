import Header from "./Components/Header";
import Section from "./Components/Section";

function App() {
  return (
    <div className="App">
      <Header />
      <Section />
    </div>
  );
}

export default App;
